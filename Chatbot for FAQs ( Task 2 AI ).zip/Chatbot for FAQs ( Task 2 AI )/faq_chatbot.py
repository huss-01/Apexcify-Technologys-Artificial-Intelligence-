import json
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from utils import clean_text, lemmatize_text

class FAQBot:
    def __init__(self, faq_path="faqs.json", min_score=0.25):
        self.faq_path = faq_path
        self.min_score = min_score
        self._load_faqs()
        self._build_vectorizer()

    def _load_faqs(self):
        with open(self.faq_path, "r", encoding="utf-8") as f:
            self.faqs = json.load(f)
        for item in self.faqs:
            item.setdefault("q","")
            item.setdefault("a","")

    def _build_vectorizer(self):
        self.questions = [lemmatize_text(clean_text(i['q'])) for i in self.faqs]
        self.vectorizer = TfidfVectorizer(ngram_range=(1,2), stop_words='english')
        self.q_matrix = self.vectorizer.fit_transform(self.questions) if self.questions else None

    def reload(self):
        self._load_faqs()
        self._build_vectorizer()

    def answer(self, user_q:str):
        if not user_q or self.q_matrix is None:
            return {"answer":"No FAQs available","score":0}
        q = lemmatize_text(clean_text(user_q))
        u_vec = self.vectorizer.transform([q])
        sims = cosine_similarity(u_vec, self.q_matrix)[0]
        idx = int(sims.argmax())
        score = float(sims[idx])
        if score < self.min_score:
            return {"answer":"Sorry, I don't have an answer. Try rephrasing.","score":score}
        return {"answer":self.faqs[idx]['a'], "score":score, "matched_question":self.faqs[idx]['q']}
