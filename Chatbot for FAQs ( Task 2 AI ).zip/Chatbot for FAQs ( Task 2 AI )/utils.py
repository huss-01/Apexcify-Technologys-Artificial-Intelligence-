import re
import nltk
from nltk.tokenize import word_tokenize
try:
    import spacy
    nlp = spacy.load("en_core_web_sm")
except Exception:
    nlp = None

nltk.download('punkt', quiet=True)

def clean_text(text: str) -> str:
    t = text.lower()
    t = re.sub(r"[^a-z0-9\s]", " ", t)
    t = re.sub(r"\s+", " ", t).strip()
    return t

def lemmatize_text(text: str) -> str:
    if nlp:
        doc = nlp(text)
        return " ".join([tok.lemma_ for tok in doc])
    else:
        return " ".join(word_tokenize(text))
