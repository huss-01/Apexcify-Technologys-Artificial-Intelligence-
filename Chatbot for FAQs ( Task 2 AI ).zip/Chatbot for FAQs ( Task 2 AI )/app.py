from flask import Flask, request, jsonify, send_from_directory
from faq_chatbot import FAQBot
import os

app = Flask(__name__, static_folder='.')

bot = FAQBot(faq_path="faqs.json", min_score=0.25)

@app.route("/ask", methods=["POST"])
def ask():
    data = request.get_json(force=True)
    q = data.get("question","")
    if not q:
        return jsonify({"error":"question missing"}), 400
    return jsonify(bot.answer(q))

@app.route("/reload", methods=["POST"])
def reload_faqs():
    bot.reload()
    return jsonify({"status":"reloaded","count":len(bot.faqs)})

@app.route("/")
def index():
    return send_from_directory(".", "chatbot_ui.html")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
