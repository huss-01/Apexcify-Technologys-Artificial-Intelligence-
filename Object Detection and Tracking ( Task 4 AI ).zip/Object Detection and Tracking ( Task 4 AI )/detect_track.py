# detect_track.py
import cv2
from ultralytics import YOLO
from centroid_tracker import CentroidTracker
import argparse
import time


def draw_tracking(frame, box, object_id, cls_name):
    x1, y1, x2, y2 = map(int, box)
    color = (0, 255, 0)

    cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
    label = f"ID {object_id} | {cls_name}"
    cv2.putText(frame, label, (x1, y1 - 7),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)


def main(video_source, weights):
    model = YOLO(weights)
    tracker = CentroidTracker(max_lost=12, iou_threshold=0.35)

    class_names = model.model.names

    cap = cv2.VideoCapture(video_source)
    if not cap.isOpened():
        print("Cannot open video source.")
        return

    prev_time = time.time()

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        results = model(frame, conf=0.4, verbose=False)

        detections = []
        for r in results:
            for b in r.boxes:
                x1, y1, x2, y2 = b.xyxy[0].tolist()
                cls = int(b.cls[0])
                detections.append([x1, y1, x2, y2, float(b.conf[0]), cls])

        objects = tracker.update(detections)

        for object_id, track_data in objects.items():
            box, cls = track_data
            class_name = class_names[cls]
            draw_tracking(frame, box, object_id, class_name)

        fps = 1 / (time.time() - prev_time)
        prev_time = time.time()
        cv2.putText(frame, f"FPS: {fps:.1f}", (10, 25),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)

        cv2.imshow("YOLOv8 Object Detection + Tracking", frame)

        if cv2.waitKey(1) & 0xFF == ord("q"):
            break

    cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--video", default="0", help="0 for webcam or path to video")
    parser.add_argument("--weights", default="yolov8n.pt", help="YOLOv8 model weights")

    args = parser.parse_args()
    video_source = int(args.video) if args.video.isdigit() else args.video

    main(video_source, args.weights)
