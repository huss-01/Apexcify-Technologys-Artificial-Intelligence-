# centroid_tracker.py
import numpy as np

def iou(boxA, boxB):
    xA = max(boxA[0], boxB[0])
    yA = max(boxA[1], boxB[1])
    xB = min(boxA[2], boxB[2])
    yB = min(boxA[3], boxB[3])

    interArea = max(0, xB - xA) * max(0, yB - yA)
    boxAArea = max(0, (boxA[2] - boxA[0])) * max(0, (boxA[3] - boxA[1]))
    boxBArea = max(0, (boxB[2] - boxB[0])) * max(0, (boxB[3] - boxB[1]))

    union = boxAArea + boxBArea - interArea
    return interArea / union if union > 0 else 0


class CentroidTracker:
    def __init__(self, max_lost=15, iou_threshold=0.3):
        self.nextObjectID = 1
        self.objects = {}
        self.lost = {}
        self.max_lost = max_lost
        self.iou_threshold = iou_threshold

    def register(self, box, cls):
        self.objects[self.nextObjectID] = (box, cls)
        self.lost[self.nextObjectID] = 0
        self.nextObjectID += 1

    def deregister(self, objectID):
        del self.objects[objectID]
        del self.lost[objectID]

    def update(self, detections):
        if len(detections) == 0:
            to_remove = []
            for objectID in list(self.lost.keys()):
                self.lost[objectID] += 1
                if self.lost[objectID] > self.max_lost:
                    to_remove.append(objectID)
            for objectID in to_remove:
                self.deregister(objectID)
            return self.objects

        input_boxes = [det[:4] for det in detections]

        if len(self.objects) == 0:
            for det in detections:
                self.register(det[:4], det[5])
            return self.objects

        objectIDs = list(self.objects.keys())
        objectBoxes = [self.objects[objID][0] for objID in objectIDs]

        iou_matrix = np.zeros((len(objectBoxes), len(input_boxes)))

        for i, oldBox in enumerate(objectBoxes):
            for j, newBox in enumerate(input_boxes):
                iou_matrix[i][j] = iou(oldBox, newBox)

        used_rows = set()
        used_cols = set()

        for row in range(iou_matrix.shape[0]):
            max_col = np.argmax(iou_matrix[row])
            if iou_matrix[row][max_col] >= self.iou_threshold and max_col not in used_cols:
                objectID = objectIDs[row]
                self.objects[objectID] = (detections[max_col][:4], detections[max_col][5])
                self.lost[objectID] = 0
                used_rows.add(row)
                used_cols.add(max_col)

        for col in range(len(input_boxes)):
            if col not in used_cols:
                self.register(detections[col][:4], detections[col][5])

        to_remove = []
        for row in range(len(objectBoxes)):
            if row not in used_rows:
                objectID = objectIDs[row]
                self.lost[objectID] += 1
                if self.lost[objectID] > self.max_lost:
                    to_remove.append(objectID)

        for objectID in to_remove:
            self.deregister(objectID)

        return self.objects
