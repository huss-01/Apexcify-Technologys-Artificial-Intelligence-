# Task 3 — Teachable Machine Image Classifier (Improved)

This package contains demos to run a Teachable Machine image classifier in Python and the browser.

Folders:
- tm_export/: place your exported model files here.
  - For Python (Keras): place `my_model.h5`
  - For Web (TF.js): place `model.json`, `metadata.json`, and *.bin shards

Files added/updated:
- Dockerfile: containerize demo
- Procfile: for Heroku-like deploys
- serve_static.py: simple Flask server to host web demo
- tm_python_demo.py: python demo (improved error messages)
- tm_web_demo.html: browser demo (guides user)

Usage (PyCharm/Local):
1. Install dependencies: `pip install -r requirements.txt`
2. Replace `tm_export/my_model.h5` with your real model.
3. Run Python demo: `python tm_python_demo.py --model tm_export/my_model.h5 --webcam`
4. Or serve web demo: `python serve_static.py` and open `http://localhost:5000/`

If TensorFlow is not installed, the Python demo will show clear instructions how to install it.

