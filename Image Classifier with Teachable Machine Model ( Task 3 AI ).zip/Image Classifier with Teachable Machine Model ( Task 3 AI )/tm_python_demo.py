#!/usr/bin/env python3
"""TM Python Demo (improved)

This script loads a Keras .h5 model and runs image or webcam classification.
It gives helpful messages if TensorFlow is not installed or model file is missing.
"""
import argparse, os, json, sys


def check_tf():
    try:
        import tensorflow as tf
        # --- COMPATIBILITY PATCH (The fix for your model) ---
        # Fix for Teachable Machine models failing on newer Keras/Python versions (like 3.13)
        # by forcing tf.keras to use the legacy Keras 2 package ('tf-keras').
        try:
            import tf_keras
            tf.keras = tf_keras
        except ImportError:
            # If tf-keras is not installed, it will fall back to default Keras 3
            pass
        # --- END PATCH ---
        return tf
    except Exception as e:
        print("\nTensorFlow is required to run this demo.")
        print("Install with: pip install tensorflow\nOr if you have GPU, install tensorflow-gpu accordingly.")
        print("Error details:", e)
        return None


def load_labels(path):
    # ... the rest of the file continues correctly here
    if os.path.exists(path):
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    return None

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', required=True, help='Path to Keras .h5 model')
    parser.add_argument('--image', help='Image file to predict')
    parser.add_argument('--webcam', action='store_true', help='Use webcam for live prediction')
    parser.add_argument('--labels', default='tm_export/labels.json', help='Path to labels.json')
    args = parser.parse_args()

    tf = check_tf()
    if tf is None:
        sys.exit(1)

    if not os.path.exists(args.model):
        print(f"Model not found at {args.model}. Place your Teachable Machine .h5 model at this path.")
        sys.exit(1)

    labels = load_labels(args.labels)
    model = tf.keras.models.load_model(args.model)
    print('Model loaded. Labels:', labels)

    import cv2, numpy as np

    IMAGE_SIZE = (224,224)
    def preprocess(frame):
        img = cv2.resize(frame, IMAGE_SIZE)
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        img = img.astype('float32')/255.0
        return np.expand_dims(img, 0)

    if args.image:
        img = cv2.imread(args.image)
        if img is None:
            print('Could not read image', args.image); sys.exit(1)
        x = preprocess(img)
        preds = model.predict(x)[0]
        idx = int(preds.argmax())
        prob = float(preds[idx])
        label = labels[idx] if labels and idx < len(labels) else str(idx)
        print(f'Predicted: {label} ({prob*100:.2f}%)')
    elif args.webcam:
        cap = cv2.VideoCapture(3)
        if not cap.isOpened():
            print('Cannot open webcam'); sys.exit(1)
        try:
            while True:
                ret, frame = cap.read()
                if not ret: break
                x = preprocess(frame)
                preds = model.predict(x)[0]
                idx = int(preds.argmax())
                prob = float(preds[idx])
                label = labels[idx] if labels and idx < len(labels) else str(idx)
                cv2.putText(frame, f"{label}: {prob*100:.1f}%", (10,30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0,255,0), 2)
                cv2.imshow('TM Python Demo', frame)
                if cv2.waitKey(1) & 0xFF == ord('q'):
                    break
        finally:
            cap.release(); import cv2; cv2.destroyAllWindows()
    else:
        print('Provide --image or --webcam')

if __name__=='__main__':
    main()
