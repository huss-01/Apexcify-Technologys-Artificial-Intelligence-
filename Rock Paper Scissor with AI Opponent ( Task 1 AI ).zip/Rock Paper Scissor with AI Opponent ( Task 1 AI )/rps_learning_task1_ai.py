# rps_ai_learning.py
import random
from collections import Counter

choices = ['rock','paper','scissors']
beats = {'rock':'scissors','paper':'rock','scissors':'paper'}

def predicted_move(history):
    # simple frequency: predict user's next move as most frequent so far
    if not history: return random.choice(choices)
    c = Counter(history)
    return c.most_common(1)[0][0]

def ai_move(history):
    pred = predicted_move(history)
    # choose the move that beats predicted user move
    for move, beaten in beats.items():
        if beaten == pred:
            return move
    return random.choice(choices)

def winner(a,b):
    if a==b: return 'tie'
    if beats[a]==b: return 'user'
    return 'ai'

def main():
    history=[]
    print("Adaptive RPS: AI learns pattern. Type exit to stop.")
    while True:
        user=input("Your move: ").strip().lower()
        if user=='exit':
            break
        if user not in choices:
            print("Invalid.")
            continue
        ai=ai_move(history)
        print("AI:",ai)
        print("Result:", winner(user,ai))
        history.append(user)

if __name__=='__main__':
    main()
