Open file 1 

-- Just put any word and the AI also check that then they who wins. 

Open File 2

-- AI learn by own and decide the move and AI automatically learn and give answers. 