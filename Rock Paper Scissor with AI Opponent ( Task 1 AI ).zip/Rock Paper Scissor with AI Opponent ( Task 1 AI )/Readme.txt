Open file 1 : rps_task1_AI.py

-- Just put any word and the AI also check that they who win.

Open File 2 : rps_learning_task1_ai.py

-- AI learn by own and decide the move and AI automatically learn and give answers. 