# rps_ai.py
import random

choices = ['rock','paper','scissors']

def winner(a,b):
    if a==b: return 'tie'
    if (a=='rock' and b=='scissors') or (a=='paper' and b=='rock') or (a=='scissors' and b=='paper'):
        return 'user'
    return 'ai'

def play_round():
    user = input("Choose rock/paper/scissors (or 'exit'): ").strip().lower()
    if user == 'exit': return None
    if user not in choices:
        print("Invalid. Try again.")
        return True
    ai = random.choice(choices)
    print(f"AI chose: {ai}")
    res = winner(user, ai)
    if res == 'tie':
        print("It's a tie.")
    elif res == 'user':
        print("You win!")
    else:
        print("AI wins.")
    return True

def main():
    print("Rock-Paper-Scissors — type 'exit' to stop.")
    while True:
        cont = play_round()
        if cont is None:
            print("Goodbye.")
            break

if __name__ == "__main__":
    main()
